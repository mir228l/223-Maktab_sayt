"use client"

import { Menu, X } from "lucide-react"
import { useState } from "react"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <div className="text-2xl font-bold text-primary">223-Maktab</div>
            <div className="text-xs text-muted-foreground">Tarbiya Markazi</div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-8">
            <a href="#" className="text-foreground hover:text-primary transition">
              Bosh sahifa
            </a>
            <a href="#grades" className="text-foreground hover:text-primary transition">
              Sinflar
            </a>
            <a href="#features" className="text-foreground hover:text-primary transition">
              Xizmatlar
            </a>
            <a href="#" className="text-foreground hover:text-primary transition">
              Aloqa
            </a>
          </nav>

          {/* Mobile menu button */}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="md:hidden pb-4 space-y-2">
            <a href="#" className="block px-4 py-2 text-foreground hover:bg-accent rounded">
              Bosh sahifa
            </a>
            <a href="#grades" className="block px-4 py-2 text-foreground hover:bg-accent rounded">
              Sinflar
            </a>
            <a href="#features" className="block px-4 py-2 text-foreground hover:bg-accent rounded">
              Xizmatlar
            </a>
            <a href="#" className="block px-4 py-2 text-foreground hover:bg-accent rounded">
              Aloqa
            </a>
          </nav>
        )}
      </div>
    </header>
  )
}
