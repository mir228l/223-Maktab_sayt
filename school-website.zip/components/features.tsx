export default function Features() {
  const features = [
    {
      number: "1",
      title: "Yuqori sifatli ta'lim",
      description: "Xalqaro standartlar asosida ta'lim dasturi",
      image: "/teacher-teaching-class-with-modern-equipment.jpg",
    },
    {
      number: "2",
      title: "Zamonaviy o'quv vositasi",
      description: "Kompyuter, laboratoriya va sport zalga ega maktab",
      image: "/modern-school-laboratory-equipment.jpg",
    },
    {
      number: "3",
      title: "Chuqur rivojlanish dasturi",
      description: "O'quvchilarning ijodiy qobiliyatini oshirish uchun maxsus darslar",
      image: "/students-doing-creative-project-work.jpg",
    },
  ]

  return (
    <section id="features" className="py-20 bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-16 text-foreground">Nima uchun 223-Maktabni tanlash kerak?</h2>

        <div className="space-y-16">
          {features.map((feature, index) => (
            <div key={index}>
              <div
                className={`grid md:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? "md:flex-row-reverse" : ""}`}
              >
                <div className={index % 2 === 1 ? "md:order-2" : ""}>
                  <div className="text-5xl font-bold text-primary mb-4">{feature.number}</div>
                  <h3 className="text-3xl font-bold mb-4 text-foreground">{feature.title}</h3>
                  <p className="text-lg text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
                <div
                  className={`relative h-96 rounded-lg overflow-hidden shadow-lg ${index % 2 === 1 ? "md:order-1" : ""}`}
                >
                  <img
                    src={feature.image || "/placeholder.svg"}
                    alt={feature.title}
                    className="w-full h-full object-cover hover:scale-105 transition duration-300"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
