"use client"

import { useState } from "react"

const gradeData = [
  {
    id: 1,
    name: "1-sinf",
    description: "Boshlang'ich ta'lim",
    students: "25-30",
    color: "bg-blue-100 text-blue-900",
    image: "/first-grade-classroom-kids-learning.jpg",
  },
  {
    id: 2,
    name: "2-sinf",
    description: "Boshlang'ich ta'lim",
    students: "25-30",
    color: "bg-green-100 text-green-900",
    image: "/second-grade-students-math-class.jpg",
  },
  {
    id: 3,
    name: "3-sinf",
    description: "Boshlang'ich ta'lim",
    students: "25-30",
    color: "bg-yellow-100 text-yellow-900",
    image: "/third-grade-reading-and-writing.jpg",
  },
  {
    id: 4,
    name: "4-sinf",
    description: "Boshlang'ich ta'lim",
    students: "25-30",
    color: "bg-purple-100 text-purple-900",
    image: "/fourth-grade-science-project.jpg",
  },
  {
    id: 5,
    name: "5-sinf",
    description: "O'rta ta'lim",
    students: "30-35",
    color: "bg-pink-100 text-pink-900",
    image: "/fifth-grade-middle-school-students.jpg",
  },
  {
    id: 6,
    name: "6-sinf",
    description: "O'rta ta'lim",
    students: "30-35",
    color: "bg-indigo-100 text-indigo-900",
    image: "/sixth-grade-classroom-study.jpg",
  },
  {
    id: 7,
    name: "7-sinf",
    description: "O'rta ta'lim",
    students: "30-35",
    color: "bg-cyan-100 text-cyan-900",
    image: "/seventh-grade-computer-lab.jpg",
  },
  {
    id: 8,
    name: "8-sinf",
    description: "O'rta ta'lim",
    students: "30-35",
    color: "bg-orange-100 text-orange-900",
    image: "/eighth-grade-laboratory-experiment.jpg",
  },
  {
    id: 9,
    name: "9-sinf",
    description: "O'rta ta'lim",
    students: "30-35",
    color: "bg-red-100 text-red-900",
    image: "/ninth-grade-exam-preparation.jpg",
  },
  {
    id: 10,
    name: "10-sinf",
    description: "Yuqori ta'lim",
    students: "25-30",
    color: "bg-teal-100 text-teal-900",
    image: "/tenth-grade-advanced-students.jpg",
  },
  {
    id: 11,
    name: "11-sinf",
    description: "Yuqori ta'lim",
    students: "25-30",
    color: "bg-lime-100 text-lime-900",
    image: "/eleventh-grade-graduation-class.jpg",
  },
]

export default function Grades() {
  const [selectedGrade, setSelectedGrade] = useState<number | null>(null)

  return (
    <section id="grades" className="py-20 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Sinflar</h2>
          <p className="text-xl text-muted-foreground">1-sinfdan 11-sinfgacha to'liq ta'lim dasturini taklif qilamiz</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {gradeData.map((grade) => (
            <div
              key={grade.id}
              onClick={() => setSelectedGrade(selectedGrade === grade.id ? null : grade.id)}
              className="cursor-pointer group"
            >
              <div className="relative h-64 rounded-lg overflow-hidden mb-4 shadow-lg hover:shadow-xl transition">
                <img
                  src={grade.image || "/placeholder.svg"}
                  alt={grade.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <div className={`absolute inset-0 ${grade.color} opacity-0 group-hover:opacity-20 transition`} />
              </div>
              <div className={`p-4 rounded-lg ${grade.color} border-2 ${grade.color.split(" ")[0]}`}>
                <h3 className="text-xl font-bold mb-1">{grade.name}</h3>
                <p className="text-sm mb-2">{grade.description}</p>
                <p className="text-xs opacity-75">O'quvchilar: {grade.students}</p>
              </div>
              {selectedGrade === grade.id && (
                <div className="mt-2 p-3 bg-accent rounded-lg text-sm">
                  <p className="mb-2">
                    <strong>Darajalashgan o'qituvchilar:</strong> Bor
                  </p>
                  <p>
                    <strong>Ta'lim materiallari:</strong> Zamonaviy va xalqaro standartlar asosida
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
