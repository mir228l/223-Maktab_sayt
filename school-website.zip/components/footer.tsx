export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-12 mb-8">
          <div>
            <h4 className="font-bold text-lg mb-4">223-Maktab</h4>
            <p className="text-primary-foreground/80">
              O'zbekistonning ta'lim tizimida yangi avlodni tayyorlash uchun mo'ljallangan ta'lim muassasasi
            </p>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-4">Havolalar</h4>
            <ul className="space-y-2 text-primary-foreground/80">
              <li>
                <a href="#" className="hover:text-white transition">
                  Bosh sahifa
                </a>
              </li>
              <li>
                <a href="#grades" className="hover:text-white transition">
                  Sinflar
                </a>
              </li>
              <li>
                <a href="#features" className="hover:text-white transition">
                  Xizmatlar
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Aloqa
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-4">Aloqa</h4>
            <ul className="space-y-2 text-primary-foreground/80">
              <li>Telefon: +998 71 123 45 67</li>
              <li>Email: info@223maktab.uz</li>
              <li>Manzil: Toshkent, O'zbekiston</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-primary-foreground/20 pt-8 text-center text-primary-foreground/60">
          <p>&copy; 2025 223-Maktab. Barcha huquqlar himoyalangan.</p>
        </div>
      </div>
    </footer>
  )
}
