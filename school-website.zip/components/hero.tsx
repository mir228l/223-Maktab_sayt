export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-primary/80 py-20 md:py-32">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-white/5 rounded-full" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-white/5 rounded-full" />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-balance">223-Maktabga xush kelibsiz</h1>
            <p className="text-xl text-white/90 mb-8 leading-relaxed">
              Ilm-fan va ta'lim sohasida yangi avlodni tayyorlash uchun mo'ljallangan. Birlashgan ta'lim tizimida 1-11
              sinfgacha o'qish imkoniyati.
            </p>
            <button className="bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-white/90 transition">
              Biz bilan bog'lanish
            </button>
          </div>
          <div className="relative h-96 rounded-lg overflow-hidden">
            <img
              src="/school-students-studying-in-classroom.jpg"
              alt="Maktab o'qituvchisi va o'quvchilar"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
